# SPDX-FileCopyrightText: 2023-present Chipy <iamchipy@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = '0.0.6'

print("Loading chipys_5e_companion v"+__version__)

